CREATE TABLE estados(
	id INT,
	nome VARCHAR(60) NOT NULL,
	sigla CHAR(2) NOT NULL,
	CONSTRAINT pk_estados_id PRIMARY KEY (id));
    
    
CREATE TABLE cidades(
	id INT,
	nome VARCHAR(100) NOT NULL,
	cep CHAR(9),
	estados_id INT NOT NULL,
	CONSTRAINT pk_cidades_id PRIMARY KEY (id),
	CONSTRAINT fk_estados_id FOREIGN KEY (estados_id) REFERENCES estados (id));
    
    
CREATE TABLE bairros(
	id INT,
	nome VARCHAR(100) NOT NULL,
	cidades_id INT NOT NULL,
	CONSTRAINT pk_bairros_id PRIMARY KEY (id),
	CONSTRAINT fk_cidades_id FOREIGN KEY (cidades_id) REFERENCES cidades (id));
    
    
CREATE TABLE endereços(
	id INT,
	logradouro VARCHAR(100) NOT NULL,
	numero VARCHAR(20) NOT NULL,
	complemento VARCHAR(20),
	cep CHAR(9),
	bairros_id INT NOT NULL,
	CONSTRAINT pk_endereços_id PRIMARY KEY (id),
	CONSTRAINT fk_bairros_id FOREIGN KEY (bairros_id) REFERENCES bairros (id));
    
    
CREATE TABLE funcoes(
	id INT,
	nome VARCHAR(60) NOT NULL,
	descricao TEXT,
	CONSTRAINT pk_funcoes_id PRIMARY KEY (id));
    
    
CREATE TABLE telefones(
	id INT,
	numero VARCHAR(14) NOT NULL,
	descricao TEXT,
	CONSTRAINT pk_telefones_id PRIMARY KEY (id));
    
    
CREATE TABLE funcionarios(
	id INT,
	nome VARCHAR(45) NOT NULL,
	sobrenome VARCHAR(200) NOT NULL,
	data_nascimento DATE NOT NULL,
	email VARCHAR(100) NOT NULL,
	RG VARCHAR(20) NOT NULL,
	CPF CHAR(19) NOT NULL,
	carteira_trabalho VARCHAR(20) NOT NULL,
	data_admissao DATE NOT NULL,
	data_demissao DATE,
	salario DECIMAL(10,2) NOT NULL,
	funcoes_id INT NOT NULL,
	endereços_id INT NOT NULL,
	endereços_natal_id INT NOT NULL,
	telefones_id INT NOT NULL,
	gerente_id INT,
	CONSTRAINT pk_funcionarios_id PRIMARY KEY (id),
	CONSTRAINT fk_funcoes_id FOREIGN KEY (funcoes_id) REFERENCES funcoes (id),
	CONSTRAINT fk_endereços_id FOREIGN KEY (endereços_id) REFERENCES endereços (id),
	CONSTRAINT fk_telefones_id FOREIGN KEY (telefones_id) REFERENCES telefones (id),
	CONSTRAINT fk_gerente_id FOREIGN KEY (gerente_id) REFERENCES funcionarios (id));
    
ALTER TABLE funcionarios ADD CONSTRAINT fk_endereços_natal_id FOREIGN KEY (endereços_natal_id) REFERENCES endereços (id);


CREATE TABLE tipo_conta(
	id INT,
	nome VARCHAR(60) NOT NULL,
	CONSTRAINT pk_tipo_conta_id PRIMARY KEY (id));


CREATE TABLE contas (
	id INT,
	metodo_pagamento VARCHAR(20) NOT NULL,
	valor DECIMAL(10,2) NOT NULL,
	data_vencimento DATE NOT NULL,
	date_pagamento DATE NOT NULL,
	funcionarios_id INT NOT NULL,
	tipo_conta_id INT NOT NULL,
	CONSTRAINT pk_contas_id PRIMARY KEY (id),
	CONSTRAINT fk_funcionarios_id FOREIGN KEY (funcionarios_id) REFERENCES funcionarios (id),
	CONSTRAINT fk_tipo_conta_id FOREIGN KEY (tipo_conta_id) REFERENCES tipo_conta (id));
    
    
CREATE TABLE fornecedores (
	id INT,
	CNPJ CHAR(14) NOT NULL,
	titulares VARCHAR(200) NOT NULL,
	nome VARCHAR(200) NOT NULL,
	email VARCHAR(100) NOT NULL,
	tipo_produto VARCHAR(45) NOT NULL,
	razao_social VARCHAR(100) NOT NULL,
	inscricao_estadual CHAR(8) NOT NULL,
	endereços_id INT NOT NULL,
	telefones_id INT NOT NULL,
	CONSTRAINT pk_fornecedores_id PRIMARY KEY (id),
	CONSTRAINT fk_endereços_id FOREIGN KEY (endereços_id) REFERENCES endereços (id),
	CONSTRAINT fk_telefones_id FOREIGN KEY (telefones_id) REFERENCES telefones (id));
    
    
CREATE TABLE bebidas (
	id INT,
	nome VARCHAR(40),
	preco_uni DECIMAL(10,2) NOT NULL,
	qntd_estoque INT NOT NULL,
	descricao TEXT,
	fornecedores_id INT NOT NULL,
	CONSTRAINT pk_bebidas_id PRIMARY KEY (id),
	CONSTRAINT fk_fornecedores_id FOREIGN KEY (fornecedores_id) REFERENCES fornecedores (id));
	
	
CREATE TABLE ingredientes (
	id INT,
	nome VARCHAR(40),
	preco_uni DECIMAL(10,2) NOT NULL,
	qntd_estoque INT NOT NULL,
	descricao TEXT,
	fornecedores_id INT NOT NULL,
	CONSTRAINT pk_ingredientes_id PRIMARY KEY (id),
	CONSTRAINT fk_fornecedores_id FOREIGN KEY (fornecedores_id) REFERENCES fornecedores (id));

