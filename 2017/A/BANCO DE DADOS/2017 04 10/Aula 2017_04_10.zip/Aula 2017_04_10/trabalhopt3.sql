SELECT nome , gerente_id, salario, CAST ((salario * 1.10) AS DECIMAL (10,2)) AS "novo_salario"
FROM funcionarios
WHERE gerente_id = 1
UNION
SELECT nome , gerente_id, salario, CAST ((salario * 1.15) AS DECIMAL (10,2)) AS "novo_salario"
FROM funcionarios
WHERE gerente_id = 2
ORDER BY nome;

SELECT nome ||' '|| sobrenome AS "Nome Completo", data_admissao
FROM funcionarios
WHERE data_admissao BETWEEN '20160101' AND '20161231'
ORDER BY data_admissao;

SELECT contas.id, funcionarios.nome ||' '|| funcionarios.sobrenome AS "Nome_Completo"
FROM contas 
INNER JOIN funcionarios ON contas.funcionarios_id = funcionarios.id
ORDER BY id;

SELECT funcionarios.nome ||' '|| funcionarios.sobrenome AS "Nome_Completo", contas.id
FROM funcionarios
LEFT JOIN contas ON funcionarios.id=contas.funcionarios_id;

SELECT id, nome, razao_social, tipo_produto
FROM fornecedores
WHERE tipo_produto IN ('bebidas');

SELECT id, nome||' '|| sobrenome, endereços_id, endereços_natal_id
FROM funcionarios
WHERE endereços_id != endereços_natal_id;

SELECT nome
FROM funcionarios
WHERE nome LIKE 'A%' OR nome LIKE 'V%';

SELECT cidades.nome, bairros.nome
FROM bairros
RIGHT JOIN cidades ON cidades.id = bairros.cidades_id
ORDER BY cidades.id;

SELECT f.id, f.nome, f.tipo_produto, b.nome
FROM fornecedores f, bebidas b
WHERE b.fornecedores_id = f.id
UNION
SELECT f.id, f.nome, f.tipo_produto, i.nome
FROM fornecedores f, ingredientes i
WHERE i.fornecedores_id = f.id
ORDER BY id;

SELECT f.nome, e.logradouro, e.numero, b.nome, c.nome, es.sigla
FROM funcionarios f, endereços e, bairros b, cidades c, estados es
WHERE f.endereços_id = e.id AND b.id = e.bairros_id AND c.id = b.cidades_id AND es.id = c.estados_id;
