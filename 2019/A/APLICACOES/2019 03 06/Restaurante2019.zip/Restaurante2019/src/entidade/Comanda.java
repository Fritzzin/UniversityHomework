package entidade;

public class Comanda {

    private int     id;
    private int     funcionario_id;
    private int     metodo_pagamento_id;
    private double  valor;
    private String  data;
    private char    situacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFuncionario_id() {
        return funcionario_id;
    }

    public void setFuncionario_id(int funcionario_id) {
        this.funcionario_id = funcionario_id;
    }

    public int getMetodo_pagamento_id() {
        return metodo_pagamento_id;
    }

    public void setMetodo_pagamento_id(int metodo_pagamento_id) {
        this.metodo_pagamento_id = metodo_pagamento_id;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public char getSituacao() {
        return situacao;
    }

    public void setSituacao(char situacao) {
        this.situacao = situacao;
    }
}
