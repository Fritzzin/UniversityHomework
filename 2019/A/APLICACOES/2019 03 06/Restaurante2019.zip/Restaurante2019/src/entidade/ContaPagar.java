package entidade;

public class ContaPagar {

    private int     id;
    private int     metodo_pagamento_id;
    private int     tipo_conta_id;
    private int     funcionario_id;
    private double  valor_cobrado;
    private double  valor_pago;
    private String  data_vencimento;
    private String  data_pagamento;
    private String  descricao;
    private char    situacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMetodo_pagamento_id() {
        return metodo_pagamento_id;
    }

    public void setMetodo_pagamento_id(int metodo_pagamento_id) {
        this.metodo_pagamento_id = metodo_pagamento_id;
    }

    public int getTipo_conta_id() {
        return tipo_conta_id;
    }

    public void setTipo_conta_id(int tipo_conta_id) {
        this.tipo_conta_id = tipo_conta_id;
    }

    public int getFuncionario_id() {
        return funcionario_id;
    }

    public void setFuncionario_id(int funcionario_id) {
        this.funcionario_id = funcionario_id;
    }

    public double getValor_cobrado() {
        return valor_cobrado;
    }

    public void setValor_cobrado(double valor_cobrado) {
        this.valor_cobrado = valor_cobrado;
    }

    public double getValor_pago() {
        return valor_pago;
    }

    public void setValor_pago(double valor_pago) {
        this.valor_pago = valor_pago;
    }

    public String getData_vencimento() {
        return data_vencimento;
    }

    public void setData_vencimento(String data_vencimento) {
        this.data_vencimento = data_vencimento;
    }

    public String getData_pagamento() {
        return data_pagamento;
    }

    public void setData_pagamento(String data_pagamento) {
        this.data_pagamento = data_pagamento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public char getSituacao() {
        return situacao;
    }

    public void setSituacao(char situacao) {
        this.situacao = situacao;
    }
}
