package entidade;

public class Produto {
    private int     id;
    private int     tipo_produto_id;
    private String  nome;
    private double  preco_uni;
    private double  qtde_estoque;
    private String  descricao;
    private char    situacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTipo_produto_id() {
        return tipo_produto_id;
    }

    public void setTipo_produto_id(int tipo_produto_id) {
        this.tipo_produto_id = tipo_produto_id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco_uni() {
        return preco_uni;
    }

    public void setPreco_uni(double preco_uni) {
        this.preco_uni = preco_uni;
    }

    public double getQtde_estoque() {
        return qtde_estoque;
    }

    public void setQtde_estoque(double qtde_estoque) {
        this.qtde_estoque = qtde_estoque;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public char getSituacao() {
        return situacao;
    }

    public void setSituacao(char situacao) {
        this.situacao = situacao;
    }
    
}
