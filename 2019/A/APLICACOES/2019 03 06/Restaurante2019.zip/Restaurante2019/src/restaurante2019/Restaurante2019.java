package restaurante2019;

import apoio.ConexaoBD;
import java.sql.Connection;
import javax.swing.JOptionPane;
import tela.FrmPrincipal;

public class Restaurante2019 {

    public static Connection conexao = null;

    public static void main(String[] args) {
        if (ConexaoBD.getInstance().getConnection() != null) {
//            JOptionPane.showMessageDialog(null, "Abriu!");
            new FrmPrincipal().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Deu problema!");
        }
    }
}
